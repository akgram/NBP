import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router'; // Importuj provideRouter
import { routes } from './app/app.routes'; // Importuj rute
import { AppComponent } from './app/app.component'; // Importuj AppComponent

bootstrapApplication(AppComponent, {
  providers: [
    provideHttpClient(),
    provideRouter(routes), // Koristi provideRouter umesto RouterModule.forRoot
  ],
}).catch(err => console.error(err));
